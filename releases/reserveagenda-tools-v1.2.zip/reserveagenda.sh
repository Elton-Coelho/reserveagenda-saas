#!/usr/bin/env bash
# ===========================================================
# ReserveAgenda Tools v1.2 - Instalador Automático Laravel 12
# ===========================================================

set -e
INSTALL_PATH="/home/deploy/reserveagenda"
LOG_FILE="/var/log/reserveagenda-install.log"

echo "============================================================"
echo "🚀 Instalando ReserveAgenda Tools v1.2 (Laravel 12 + PHP 8.3)"
echo "============================================================"

apt update -y && apt install -y unzip curl git php php-cli php-mbstring php-xml php-curl php-zip composer apache2 libapache2-mod-php

if [ ! -d "$INSTALL_PATH" ]; then
    mkdir -p $INSTALL_PATH
fi

cd $INSTALL_PATH

composer install --no-interaction --prefer-dist --optimize-autoloader

if [ ! -f ".env" ]; then
    cp templates/env.template .env
fi

php artisan key:generate || true

php artisan config:clear || true
php artisan cache:clear || true
php artisan route:clear || true

bash installer-tools/permissions.sh

systemctl restart apache2

echo "✅ Instalação concluída com sucesso!"
echo "Acesse: http://SEU_IP/saude"
echo "Logs salvos em: $LOG_FILE"
