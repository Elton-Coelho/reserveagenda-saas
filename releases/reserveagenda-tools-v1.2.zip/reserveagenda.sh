#!/usr/bin/env bash
# ------------------------------------------------------
# reserveagenda.sh - instalador interno do pacote
# ------------------------------------------------------

APP_PATH=${1:-/home/deploy/reserveagenda}
APP_NAME=${2:-ReserveAgenda}
APP_DOMAIN=${3:-localhost}
USE_MYSQL=${4:-y}
DB_HOST=${5:-127.0.0.1}
DB_PORT=${6:-3306}
DB_DATABASE=${7:-reserveagenda}
DB_USERNAME=${8:-usuario}
DB_PASSWORD=${9:-senha}

echo "Iniciando instalação interna..."
mkdir -p "$APP_PATH"
cd "$APP_PATH" || exit 1

# Baixar o core Laravel
echo "Baixando núcleo Laravel..."
git clone https://github.com/laravel/laravel.git . >/dev/null 2>&1

# Instalar dependências
echo "Instalando dependências PHP..."
composer install --no-interaction --optimize-autoloader >/dev/null 2>&1

# Criar .env
echo "Configurando ambiente..."
cp .env.example .env
sed -i "s|APP_NAME=.*|APP_NAME=\"${APP_NAME}\"|g" .env
sed -i "s|APP_URL=.*|APP_URL=http://${APP_DOMAIN}|g" .env

if [[ "$USE_MYSQL" =~ ^[Yy] ]]; then
  sed -i "s|DB_CONNECTION=.*|DB_CONNECTION=mysql|g" .env
  sed -i "s|DB_HOST=.*|DB_HOST=${DB_HOST}|g" .env
  sed -i "s|DB_PORT=.*|DB_PORT=${DB_PORT}|g" .env
  sed -i "s|DB_DATABASE=.*|DB_DATABASE=${DB_DATABASE}|g" .env
  sed -i "s|DB_USERNAME=.*|DB_USERNAME=${DB_USERNAME}|g" .env
  sed -i "s|DB_PASSWORD=.*|DB_PASSWORD=${DB_PASSWORD}|g" .env
else
  sed -i "s|DB_CONNECTION=.*|DB_CONNECTION=sqlite|g" .env
  touch database/database.sqlite
fi

php artisan key:generate --ansi >/dev/null 2>&1

# Permissões
chown -R www-data:www-data "$APP_PATH"
chmod -R 755 "$APP_PATH/storage"

# Adicionar páginas de teste
cp templates/info.php public/info.php
cp templates/healthcheck.php public/healthcheck.php

echo "✅ Instalação interna concluída!"