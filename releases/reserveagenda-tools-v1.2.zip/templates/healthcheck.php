<?php
use Illuminate\Support\Facades\Route;

Route::get('/saude', function () {
    return response()->json([
        'app' => config('app.name'),
        'env' => config('app.env'),
        'php' => PHP_VERSION,
        'laravel' => app()->version(),
        'time' => now()->toDateTimeString(),
    ]);
});
