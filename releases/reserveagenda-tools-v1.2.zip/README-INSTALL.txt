ReserveAgenda Tools v1.2 (Laravel 12 / PHP 8.3)
--------------------------------------------------

1️⃣ Descompacte o arquivo:
   unzip reserveagenda-tools-v1.2.zip -d /usr/local/reserveagenda/installer/

2️⃣ Dê permissão:
   chmod +x /usr/local/reserveagenda/installer/reserveagenda-tools-v1.2/*.sh

3️⃣ Execute:
   bash /usr/local/reserveagenda/installer/reserveagenda-tools-v1.2/reserveagenda.sh

4️⃣ Teste:
   - http://SEU_IP/saude
   - http://SEU_IP/info.php
