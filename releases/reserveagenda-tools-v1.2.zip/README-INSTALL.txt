===================================================
 ReserveAgenda - Instalação Automática
===================================================

Para instalar em qualquer VPS (Ubuntu 22/24 LTS):

1️⃣ Execute:
    sudo su
    curl -sSL https://raw.githubusercontent.com/Elton-Coelho/reserveagenda-saas/main/instalar/index.sh | bash

2️⃣ Siga as instruções do instalador:
    - Informe o nome da empresa
    - Domínio/IP
    - Dados do banco (opcional)

3️⃣ Ao final acesse:
    - http://SEU_DOMINIO/saude
    - http://SEU_DOMINIO/info.php

===================================================
Suporte Técnico: contato.super.zapp@gmail.com
===================================================