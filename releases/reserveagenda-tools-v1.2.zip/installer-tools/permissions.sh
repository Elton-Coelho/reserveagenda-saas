#!/usr/bin/env bash
cd /home/deploy/reserveagenda

chown -R www-data:www-data storage bootstrap/cache
chmod -R 775 storage bootstrap/cache

echo "🔒 Permissões ajustadas com sucesso."
