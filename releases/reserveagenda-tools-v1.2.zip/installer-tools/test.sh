#!/usr/bin/env bash
echo "✅ Testando ambiente Laravel..."
php artisan --version
php -v
