#!/usr/bin/env bash
# Template de rollback Laravel (v1.1)
set -Eeuo pipefail
APP_DIR="${1:-}"
APP_USER="${2:-deploy}"

[ -z "$APP_DIR" ] && { echo "Uso: $0 <APP_DIR> [APP_USER]"; exit 1; }

cd "$APP_DIR" || { echo "❌ Pasta não encontrada: $APP_DIR"; exit 1; }

DATE_NOW=$(date +"%Y%m%d_%H%M%S")
BACKUP_DIR="${APP_DIR}/storage/backups"
mkdir -p "$BACKUP_DIR"

echo "=========================================================="
echo "🧯 Iniciando rollback do ReserveAgenda"
echo "=========================================================="

# Tenta backup PostgreSQL se credenciais existirem no .env
if command -v psql >/dev/null 2>&1 && command -v pg_dump >/dev/null 2>&1; then
  if [ -f ".env" ]; then
    set -a; source .env; set +a
    if [[ "${DB_CONNECTION:-}" == "pgsql" ]]; then
      PGPASSWORD="${DB_PASSWORD:-}" pg_dump -h "${DB_HOST:-localhost}" -p "${DB_PORT:-5432}" -U "${DB_USERNAME:-}" "${DB_DATABASE:-}" \
        > "${BACKUP_DIR}/rollback_${DATE_NOW}.sql" || echo "⚠️  Backup PG falhou."
    fi
  fi
fi

if [ -f "artisan" ] && command -v php >/dev/null 2>&1; then
  echo "↩️  Revertendo última migração..."
  sudo -u "$APP_USER" php artisan migrate:rollback --step=1 --force || echo "⚠️  Nenhuma migração a reverter."
  echo "🧹 Limpando caches..."
  sudo -u "$APP_USER" php artisan optimize:clear || true
fi

echo "✅ Rollback finalizado."
echo "📁 Backup (se houver): ${BACKUP_DIR}/rollback_${DATE_NOW}.sql"
