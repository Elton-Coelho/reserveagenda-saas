#!/usr/bin/env bash
# Template de instalação Laravel (v1.1)
set -Eeuo pipefail
APP_DIR="${1:-}"
APP_USER="${2:-deploy}"

[ -z "$APP_DIR" ] && { echo "Uso: $0 <APP_DIR> [APP_USER]"; exit 1; }

cd "$APP_DIR" || { echo "❌ Pasta não encontrada: $APP_DIR"; exit 1; }

echo "=========================================================="
echo "🛠️  Instalando dependências com Composer..."
echo "=========================================================="
sudo -u "$APP_USER" composer install --no-dev --prefer-dist -q

echo "🔑 Gerando key da aplicação..."
sudo -u "$APP_USER" php artisan key:generate --force

echo "🗄️  Executando migrações e seeds..."
sudo -u "$APP_USER" php artisan migrate --force
sudo -u "$APP_USER" php artisan db:seed --force || true

echo "🔗 Criando storage:link..."
sudo -u "$APP_USER" php artisan storage:link || true

echo "🔧 Ajustando permissões..."
chown -R "$APP_USER":"$APP_USER" storage bootstrap/cache
chmod -R 775 storage bootstrap/cache

echo "🧹 Otimizando..."
sudo -u "$APP_USER" php artisan optimize:clear
sudo -u "$APP_USER" php artisan optimize

echo "✅ Instalação Laravel concluída com sucesso."
