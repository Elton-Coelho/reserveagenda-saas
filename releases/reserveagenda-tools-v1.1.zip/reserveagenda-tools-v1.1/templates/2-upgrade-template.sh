#!/usr/bin/env bash
# Template de upgrade Laravel (v1.1)
set -Eeuo pipefail
APP_DIR="${1:-}"
APP_USER="${2:-deploy}"
BRANCH="${3:-main}"

[ -z "$APP_DIR" ] && { echo "Uso: $0 <APP_DIR> [APP_USER] [BRANCH]"; exit 1; }

cd "$APP_DIR" || { echo "❌ Pasta não encontrada: $APP_DIR"; exit 1; }

echo "=========================================================="
echo "⬆️  Atualizando código a partir do branch ${BRANCH}..."
echo "=========================================================="
sudo -u "$APP_USER" git fetch --all --prune
sudo -u "$APP_USER" git reset --hard "origin/${BRANCH}"

if command -v composer >/dev/null 2>&1; then
  echo "📦 Atualizando dependências..."
  sudo -u "$APP_USER" composer install --no-dev --prefer-dist -q
fi

if [ -f "artisan" ] && command -v php >/dev/null 2>&1; then
  echo "🗄️  Rodando migrações..."
  sudo -u "$APP_USER" php artisan migrate --force
  echo "🧹 Limpando caches..."
  sudo -u "$APP_USER" php artisan optimize:clear
fi

echo "✅ Upgrade concluído."
