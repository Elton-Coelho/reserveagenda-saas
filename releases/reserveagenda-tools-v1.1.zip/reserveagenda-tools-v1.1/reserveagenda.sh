#!/usr/bin/env bash
# ==========================================================
# 🚀 ReserveAgenda - Orquestrador de Instalação (v1.1)
# Autor: Grupo Shark / Super Zapp / ReserveAgenda
# Licença: Privado (Distribuição interna Grupo Shark)
# ==========================================================

set -Eeuo pipefail

APP_NAME="reserveagenda"
APP_USER="deploy"
APP_DIR="/home/${APP_USER}/${APP_NAME}"
BRANCH_DEFAULT="main"
REPO_OWNER="Elton-Coelho"
REPO_NAME="reserveagenda-core"

# ---- Utilitários ----
msg() { echo -e "$1"; }
die() { echo -e "❌ $1"; exit 1; }

# ---- Carrega .env se existir ----
ENV_FILE="$(dirname "$0")/.env"
[ -f "$ENV_FILE" ] && set -a && source "$ENV_FILE" && set +a

# Preferência: variável de ambiente > .env
GITHUB_USERNAME="${GITHUB_USERNAME:-$REPO_OWNER}"
GITHUB_TOKEN="${GITHUB_TOKEN:-${GITHUB_PAT:-${TOKEN:-""}}}"

# ---- Checagens iniciais ----
if ! command -v git >/dev/null 2>&1; then
  apt update -y >/dev/null || true
  apt install -y git curl unzip ca-certificates >/dev/null || true
fi

# Cria usuário deploy se não existir
if ! id -u "$APP_USER" >/dev/null 2>&1; then
  msg "👤 Criando usuário ${APP_USER}..."
  useradd -m -s /bin/bash "$APP_USER"
fi

# Pasta da app
mkdir -p "$APP_DIR"
chown -R "${APP_USER}:${APP_USER}" "$(dirname "$APP_DIR")"

# ---- Monta URL do repositório privado ----
if [[ -z "$GITHUB_TOKEN" ]]; then
  die "GITHUB_TOKEN não encontrado.\n  ➜ Defina via: export GITHUB_TOKEN=github_pat_xxx\n  ➜ Ou crie .env ao lado deste script com:\n      GITHUB_TOKEN=github_pat_xxx\n      GITHUB_USERNAME=${REPO_OWNER}\n"
fi

REPO_URL="https://${GITHUB_USERNAME}:${GITHUB_TOKEN}@github.com/${REPO_OWNER}/${REPO_NAME}.git"

msg "=========================================================="
msg "🧭 Iniciando orquestração do ${APP_NAME} (${BRANCH_DEFAULT})"
msg "📁 Diretório da app: ${APP_DIR}"
msg "=========================================================="

# ---- Clonar ou atualizar ----
if [ ! -d "${APP_DIR}/.git" ]; then
  msg "📥 Clonando repositório privado..."
  sudo -u "$APP_USER" git clone --branch "${BRANCH_DEFAULT}" --depth 1 "${REPO_URL}" "${APP_DIR}"     || die "Falha ao clonar repositório. Verifique token/permissões."
else
  msg "🔄 Repositório existente. Atualizando..."
  pushd "${APP_DIR}" >/dev/null
  sudo -u "$APP_USER" git fetch --all --prune
  sudo -u "$APP_USER" git reset --hard "origin/${BRANCH_DEFAULT}"
  popd >/dev/null
fi

# ---- PHP e Composer (se presentes) ----
if command -v php >/dev/null 2>&1; then
  if ! command -v composer >/devnull 2>&1; then
    msg "📦 Instalando Composer (global)..."
    EXPECTED_SIGNATURE="$(curl -fsSL https://composer.github.io/installer.sig)"
    php -r "copy('https://getcomposer.org/installer', 'composer-setup.php');"
    ACTUAL_SIGNATURE="$(php -r "echo hash_file('sha384', 'composer-setup.php');")"
    if [ "$EXPECTED_SIGNATURE" != "$ACTUAL_SIGNATURE" ]; then
      rm composer-setup.php; die "Assinatura do Composer inválida."
    fi
    php composer-setup.php --quiet --install-dir=/usr/local/bin --filename=composer
    rm composer-setup.php
  fi
else
  msg "⚠️ PHP não encontrado. Os passos de instalação Laravel serão pulados."
fi

# ---- Executa Template de Instalação (se Laravel) ----
if [ -f "${APP_DIR}/artisan" ] && command -v php >/dev/null 2>&1; then
  msg "🧩 Executando template de instalação Laravel..."
  bash "$(dirname "$0")/templates/1-install-template.sh" "${APP_DIR}" "${APP_USER}"
else
  msg "ℹ️ Estrutura Laravel não detectada (artisan ausente). Apenas clonagem realizada."
fi

# ---- Final ----
msg "=========================================================="
msg "✅ Orquestração concluída."
msg "📍 App: ${APP_DIR}"
msg "🧰 Templates disponíveis:"
msg "   - templates/2-upgrade-template.sh"
msg "   - templates/3-rollback-template.sh"
msg "=========================================================="
