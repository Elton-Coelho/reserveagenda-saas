#!/usr/bin/env bash
# Healthcheck básico (v1.1)
set -Eeuo pipefail
services=("nginx" "apache2" "php8.2-fpm" "php8.1-fpm" "postgresql" "mysql")
for s in "${services[@]}"; do
  if systemctl list-unit-files | grep -q "^${s}\.service"; then
    systemctl is-active --quiet "$s" && state="🟢 active" || state="🔴 inactive"
    echo "${s}: ${state}"
  fi
done
