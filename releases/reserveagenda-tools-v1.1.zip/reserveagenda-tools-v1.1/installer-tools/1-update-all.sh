#!/usr/bin/env bash
# Atualização global (v1.1)
set -Eeuo pipefail
APP_DIR="${1:-/home/deploy/reserveagenda}"
APP_USER="${2:-deploy}"
BRANCH="${3:-main}"
bash "$(dirname "$0")/../templates/2-upgrade-template.sh" "$APP_DIR" "$APP_USER" "$BRANCH"
