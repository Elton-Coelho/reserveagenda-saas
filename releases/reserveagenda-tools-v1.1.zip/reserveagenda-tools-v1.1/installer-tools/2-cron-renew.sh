#!/usr/bin/env bash
# Renovação de certificados (v1.1)
set -Eeuo pipefail
if command -v certbot >/dev/null 2>&1; then
  certbot renew --quiet || true
  if command -v systemctl >/dev/null 2>&1; then
    systemctl reload nginx 2>/dev/null || true
    systemctl reload apache2 2>/dev/null || true
  fi
else
  echo "certbot não encontrado - nada a fazer."
fi
